---
name: article-search-bar
description: 为存勤法税项目新增文章页自动添加文内关键词搜索栏。包含 CSS、HTML、JS 三个代码块的插入点和完整代码。用于新建文章或批量添加搜索功能。
agent_created: true
---

# 文章页文内搜索栏

为存勤法税项目 `source/articles/` 下的文章页添加 sticky 文内关键词搜索栏。
每篇文章页必须包含此功能（2026-05-23 起强制要求）。

## 批量添加（已有文章）

使用 `scripts/add_article_search.py`：

```bash
python3 .workbuddy/skills/article-search-bar/scripts/add_article_search.py
```

脚本自动扫描 `source/articles/*.html`，跳过已有搜索栏的文章，在未添加的文章中插入三个代码块。

## 新增文章时手动添加

新建文章文件后，必须在三个位置插入以下代码块：

### 位置 1: CSS（搜索栏样式 + mark 高亮样式）

在 `/* 文章目录（侧边栏） */` 注释之前插入：

```css
/* ===== 文内搜索栏 ===== */
    .article-search-bar {
      position: sticky;
      top: 64px;
      z-index: 999;
      background: #fff;
      border-bottom: 1px solid var(--dt-border);
      padding: 0.6rem 0;
      box-shadow: 0 1px 6px rgba(0,0,0,0.05);
    }
    .article-search-inner {
      max-width: 1140px;
      margin: 0 auto;
      padding: 0 1rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .article-search-inner input {
      flex: 1;
      max-width: 400px;
      border: 1px solid var(--dt-border);
      border-radius: 4px;
      padding: 0.4rem 0.8rem;
      font-size: 0.9rem;
      font-family: inherit;
      color: var(--dt-text);
      outline: none;
      transition: border-color 0.2s;
    }
    .article-search-inner input:focus { border-color: var(--dt-accent); }
    .article-search-count {
      font-size: 0.82rem;
      color: var(--dt-text-light);
      white-space: nowrap;
    }
    .search-nav-btn {
      background: none;
      border: 1px solid var(--dt-border);
      border-radius: 4px;
      padding: 0.3rem 0.6rem;
      cursor: pointer;
      color: var(--dt-text-light);
      font-size: 0.85rem;
      font-family: inherit;
      transition: all 0.2s;
    }
    .search-nav-btn:hover { border-color: var(--dt-accent); color: var(--dt-accent); }
    .search-nav-btn:disabled { opacity: 0.35; cursor: default; }
    mark.search-mark {
      background: #ffe066;
      color: inherit;
      padding: 0 1px;
      border-radius: 2px;
    }
    mark.search-mark.active {
      background: #ff8c00;
      color: #fff;
    }
```

### 位置 2: HTML（搜索栏 UI）

在 `</section>` (hero 区的闭合标签) 和 `<!-- ===== 文章布局` 之间插入：

```html
<!-- ===== 文内搜索栏 ===== -->
<div class="article-search-bar" id="articleSearchBar">
  <div class="article-search-inner">
    <input type="text" id="articleSearchInput" placeholder="在本文中搜索关键词..." onkeydown="if(event.key==='Enter'){doArticleSearch();event.preventDefault();}" oninput="doArticleSearch()">
    <span class="article-search-count" id="articleSearchCount"></span>
    <button class="search-nav-btn" onclick="jumpToMatch(-1)" title="上一个" id="searchPrevBtn" disabled><i class="fas fa-chevron-up"></i></button>
    <button class="search-nav-btn" onclick="jumpToMatch(1)" title="下一个" id="searchNextBtn" disabled><i class="fas fa-chevron-down"></i></button>
  </div>
</div>
```

### 位置 3: JS（搜索逻辑）

在尾部 `</script>` 之前插入：

```javascript
var articleCurrentMatch = -1;
var articleTotalMatches = 0;

function doArticleSearch() {
  var q = document.getElementById('articleSearchInput').value.trim();

  // 清除旧高亮
  var oldMarks = document.querySelectorAll('.article-body mark.search-mark');
  oldMarks.forEach(function(m) {
    var parent = m.parentNode;
    parent.replaceChild(document.createTextNode(m.textContent), m);
    parent.normalize();
  });

  articleCurrentMatch = -1;
  articleTotalMatches = 0;

  if (!q || q.length < 1) {
    document.getElementById('articleSearchCount').textContent = '';
    document.getElementById('searchPrevBtn').disabled = true;
    document.getElementById('searchNextBtn').disabled = true;
    return;
  }

  var body = document.querySelector('.article-body');
  if (!body) return;

  highlightInElement(body, q);

  articleTotalMatches = document.querySelectorAll('.article-body mark.search-mark').length;
  document.getElementById('articleSearchCount').textContent = articleTotalMatches + ' 处匹配';
  document.getElementById('searchPrevBtn').disabled = articleTotalMatches === 0;
  document.getElementById('searchNextBtn').disabled = articleTotalMatches === 0;

  if (articleTotalMatches > 0) {
    jumpToMatch(1);
  }
}

function highlightInElement(element, keyword) {
  var lowerKw = keyword.toLowerCase();
  var walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, {
    acceptNode: function(n) {
      if (n.parentNode && (n.parentNode.nodeName === 'SCRIPT' || n.parentNode.nodeName === 'STYLE' || n.parentNode.nodeName === 'MARK')) {
        return NodeFilter.FILTER_REJECT;
      }
      return NodeFilter.FILTER_ACCEPT;
    }
  });

  var textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);

  textNodes.forEach(function(node) {
    var text = node.textContent;
    var idx = text.toLowerCase().indexOf(lowerKw);
    if (idx === -1) return;

    var fragment = document.createDocumentFragment();
    var lastIdx = 0;
    while (idx !== -1) {
      if (idx > lastIdx) {
        fragment.appendChild(document.createTextNode(text.substring(lastIdx, idx)));
      }
      var mark = document.createElement('mark');
      mark.className = 'search-mark';
      mark.textContent = text.substring(idx, idx + keyword.length);
      fragment.appendChild(mark);
      lastIdx = idx + keyword.length;
      idx = text.toLowerCase().indexOf(lowerKw, lastIdx);
    }
    if (lastIdx < text.length) {
      fragment.appendChild(document.createTextNode(text.substring(lastIdx)));
    }
    node.parentNode.replaceChild(fragment, node);
  });
}

function jumpToMatch(direction) {
  var marks = document.querySelectorAll('.article-body mark.search-mark');
  if (marks.length === 0) return;

  marks.forEach(function(m) { m.classList.remove('active'); });

  if (articleCurrentMatch === -1) {
    articleCurrentMatch = direction > 0 ? 0 : marks.length - 1;
  } else {
    articleCurrentMatch += direction;
    if (articleCurrentMatch >= marks.length) articleCurrentMatch = 0;
    if (articleCurrentMatch < 0) articleCurrentMatch = marks.length - 1;
  }

  var target = marks[articleCurrentMatch];
  target.classList.add('active');
  target.scrollIntoView({behavior: 'smooth', block: 'center'});
}
```

## 验证清单

新增文章后，用以下命令确认三块都已插入：

```bash
grep -c "article-search-bar\|doArticleSearch\|jumpToMatch" source/articles/新文章(source).html
# 应输出 3（三个块各至少匹配一次）
```

CSS 应有 `article-search-bar`、HTML 应有 `article-search-bar`、JS 应有 `doArticleSearch`。

## 功能说明

- **位置**: hero 区下方，sticky 吸附（`top: 64px`），随页面滚动始终可见
- **输入即搜**: `oninput` 实时高亮关键词
- **高亮**: 所有匹配用黄色 `<mark>` 高亮（`.search-mark`）
- **计数**: 显示「N 处匹配」
- **定位**: ↑↓ 按钮逐一定位，当前匹配用橙色高亮（`.search-mark.active`）
- **循环**: 到头/到尾自动循环跳转
- **搜索范围**: 仅 `.article-body` 元素内
